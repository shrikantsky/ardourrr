/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config, { isServer }) => {
    // Add the html-loader rule for handling HTML files
    config.module.rules.push({
      test: /\.html$/,
      use: "html-loader",
    });

    // If you need to handle other file types or customize the loader further, you can modify the rule accordingly.

    return config;
  },
};

module.exports = nextConfig;
