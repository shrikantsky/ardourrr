module.exports = {
  // ...
  webpack: {
    configure: (webpackConfig, { env, paths }) => {
      /* ... */
      webpackConfig.module.rules.push({
        test: /\.html$/i,
        loader: "html-loader",
      });

      return webpackConfig;
    },
  },
};
